var builder = DistributedApplication.CreateBuilder(args);

builder.Build().Run();
